// ---------- Config ----------
const GENRES = ["Fuji", "Afrobeat", "Highlife", "Gospel", "Blues", "Amapiano", "Hip-Hop", "Juju", "Rap", "Jazz", "Piano", "Classical", "Unsorted"];
const MOODS = ["Uplifting", "Reflective", "Worship", "Party", "Chill", "Motivated", "Heartbreak"];

const GENRE_HINTS = {
  fuji: "Fuji", wasiu: "Fuji", pasuma: "Fuji", obesere: "Fuji",
  afrobeat: "Afrobeat", afro: "Afrobeat", fela: "Afrobeat", burna: "Afrobeat", wizkid: "Afrobeat", davido: "Afrobeat",
  highlife: "Highlife", osadebe: "Highlife",
  gospel: "Gospel", worship: "Gospel", praise: "Gospel",
  blues: "Blues", "b.b": "Blues", muddy: "Blues",
  amapiano: "Amapiano",
  juju: "Juju", "king sunny": "Juju", obey: "Juju",
  "hip hop": "Hip-Hop", "hip-hop": "Hip-Hop", "hiphop": "Hip-Hop",
  rap: "Rap",
  jazz: "Jazz", coltrane: "Jazz", davis: "Jazz",
  piano: "Piano", chopin: "Piano", "solo piano": "Piano",
  classical: "Classical", classic: "Classical", symphony: "Classical", orchestra: "Classical", mozart: "Classical", beethoven: "Classical",
};

function guessGenre(filename) {
  const lower = filename.toLowerCase();
  for (const key in GENRE_HINTS) if (lower.includes(key)) return GENRE_HINTS[key];
  return "Unsorted";
}

function formatTime(sec) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

// ---------- IndexedDB ----------
const DB_NAME = "crates-db";
const STORE = "tracks";
let db;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const d = req.result;
      if (!d.objectStoreNames.contains(STORE)) {
        const store = d.createObjectStore(STORE, { keyPath: "id", autoIncrement: true });
        store.createIndex("byNameSize", ["name", "size"], { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function dbAll() {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function dbAdd(record) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    const req = tx.objectStore(STORE).add(record);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function dbUpdate(record) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    const req = tx.objectStore(STORE).put(record);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function dbDelete(id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    const req = tx.objectStore(STORE).delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// ---------- State ----------
let tracks = []; // {id, name, size, lastModified, genre, mood, blob, url}
let currentId = null;
let isPlaying = false;
let shuffle = true;
let activeFilter = null; // {type, value}

const audio = document.getElementById("audio");
const els = {
  addBtn: document.getElementById("addBtn"),
  fileInput: document.getElementById("fileInput"),
  genreCrates: document.getElementById("genreCrates"),
  moodCrates: document.getElementById("moodCrates"),
  clearFilter: document.getElementById("clearFilter"),
  emptyState: document.getElementById("emptyState"),
  trackList: document.getElementById("trackList"),
  listHeader: document.getElementById("listHeader"),
  rows: document.getElementById("rows"),
  toast: document.getElementById("toast"),
  disc: document.getElementById("disc"),
  npTitle: document.getElementById("npTitle"),
  npMeta: document.getElementById("npMeta"),
  shuffleBtn: document.getElementById("shuffleBtn"),
  prevBtn: document.getElementById("prevBtn"),
  playBtn: document.getElementById("playBtn"),
  playIcon: document.getElementById("playIcon"),
  nextBtn: document.getElementById("nextBtn"),
  seek: document.getElementById("seek"),
  curTime: document.getElementById("curTime"),
  durTime: document.getElementById("durTime"),
  volume: document.getElementById("volume"),
};

let toastTimer;
function showToast(msg) {
  els.toast.textContent = msg;
  els.toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (els.toast.hidden = true), 2200);
}

// ---------- Rendering ----------
function currentTrack() {
  return tracks.find((t) => t.id === currentId) || null;
}

function filteredTracks() {
  if (!activeFilter) return tracks;
  return tracks.filter((t) => (activeFilter.type === "genre" ? t.genre : t.mood) === activeFilter.value);
}

function counts(list, field) {
  const map = {};
  list.forEach((v) => (map[v] = 0));
  tracks.forEach((t) => (map[t[field]] = (map[t[field]] || 0) + 1));
  return map;
}

function renderCrates() {
  const gc = counts(GENRES, "genre");
  els.genreCrates.innerHTML = GENRES.map(
    (g) => `<button class="chip ${activeFilter?.type === "genre" && activeFilter.value === g ? "active" : ""}" data-type="genre" data-value="${g}">
      <span>${g}</span><span class="chip-count">${gc[g] || 0}</span>
    </button>`
  ).join("");

  const mc = counts(MOODS, "mood");
  els.moodCrates.innerHTML = MOODS.map(
    (m) => `<button class="chip ${activeFilter?.type === "mood" && activeFilter.value === m ? "active" : ""}" data-type="mood" data-value="${m}">
      <span>${m}</span><span class="chip-count">${mc[m] || 0}</span>
    </button>`
  ).join("");

  document.querySelectorAll(".chip").forEach((btn) => {
    btn.addEventListener("click", () => playFilter(btn.dataset.type, btn.dataset.value));
  });

  els.clearFilter.hidden = !activeFilter;
}

function renderList() {
  const list = filteredTracks();
  if (tracks.length === 0) {
    els.emptyState.hidden = false;
    els.trackList.hidden = true;
    return;
  }
  els.emptyState.hidden = true;
  els.trackList.hidden = false;
  els.listHeader.textContent = activeFilter
    ? `${activeFilter.value} · ${list.length} track${list.length === 1 ? "" : "s"}`
    : `Library · ${tracks.length} track${tracks.length === 1 ? "" : "s"}`;

  els.rows.innerHTML = list
    .map(
      (t) => `
    <div class="row ${t.id === currentId ? "active" : ""}" data-id="${t.id}">
      <button class="row-play" data-action="play" data-id="${t.id}">
        ${t.id === currentId && isPlaying ? playSvg(false) : playSvg(true)}
      </button>
      <div class="row-name" title="${t.name}">${t.name}</div>
      <select data-action="genre" data-id="${t.id}">
        ${GENRES.map((g) => `<option value="${g}" ${g === t.genre ? "selected" : ""}>${g}</option>`).join("")}
      </select>
      <select data-action="mood" data-id="${t.id}">
        ${MOODS.map((m) => `<option value="${m}" ${m === t.mood ? "selected" : ""}>${m}</option>`).join("")}
      </select>
      <button class="row-remove" data-action="remove" data-id="${t.id}">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M6 6l12 12M6 18L18 6"/></svg>
      </button>
    </div>`
    )
    .join("");

  els.rows.querySelectorAll("[data-action='play']").forEach((b) =>
    b.addEventListener("click", () => playTrackId(Number(b.dataset.id)))
  );
  els.rows.querySelectorAll("[data-action='genre']").forEach((s) =>
    s.addEventListener("change", () => updateTag(Number(s.dataset.id), "genre", s.value))
  );
  els.rows.querySelectorAll("[data-action='mood']").forEach((s) =>
    s.addEventListener("change", () => updateTag(Number(s.dataset.id), "mood", s.value))
  );
  els.rows.querySelectorAll("[data-action='remove']").forEach((b) =>
    b.addEventListener("click", () => removeTrack(Number(b.dataset.id)))
  );
}

function playSvg(playIcon) {
  return playIcon
    ? `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`
    : `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg>`;
}

function renderPlayer() {
  const t = currentTrack();
  els.npTitle.textContent = t ? t.name : "Nothing playing";
  els.npMeta.textContent = t ? `${t.genre} · ${t.mood}` : "Pick a crate or a track";
  els.playIcon.innerHTML = isPlaying
    ? `<path d="M6 5h4v14H6zm8 0h4v14h-4z"/>`
    : `<path d="M8 5v14l11-7z"/>`;
  els.disc.classList.toggle("spinning", isPlaying);
  els.shuffleBtn.classList.toggle("on", shuffle);
}

function renderAll() {
  renderCrates();
  renderList();
  renderPlayer();
}

// ---------- Playback ----------
function playTrackId(id) {
  currentId = id;
  isPlaying = true;
  const t = currentTrack();
  audio.src = t.url;
  audio.play().catch(() => {});
  updateMediaSession(t);
  renderAll();
}

function playFilter(type, value) {
  activeFilter = { type, value };
  const pool = tracks.filter((t) => (type === "genre" ? t.genre : t.mood) === value);
  if (pool.length === 0) {
    showToast(`No tracks tagged "${value}" yet. Tag some below.`);
    renderAll();
    return;
  }
  const pick = shuffle ? pool[Math.floor(Math.random() * pool.length)] : pool[0];
  playTrackId(pick.id);
}

function clearFilterFn() {
  activeFilter = null;
  renderAll();
}

function stepTrack(dir) {
  const pool = filteredTracks().length ? filteredTracks() : tracks;
  if (pool.length === 0) return;
  const t = currentTrack();
  if (!t) return playTrackId(pool[0].id);
  if (shuffle) {
    const others = pool.filter((x) => x.id !== t.id);
    const pick = others.length ? others[Math.floor(Math.random() * others.length)] : pool[0];
    return playTrackId(pick.id);
  }
  const idx = pool.findIndex((x) => x.id === t.id);
  const nextIdx = (idx + dir + pool.length) % pool.length;
  playTrackId(pool[nextIdx].id);
}

function togglePlay() {
  const t = currentTrack();
  if (!t) {
    const pool = filteredTracks().length ? filteredTracks() : tracks;
    if (pool.length) playTrackId(pool[0].id);
    return;
  }
  isPlaying = !isPlaying;
  if (isPlaying) audio.play().catch(() => {});
  else audio.pause();
  renderPlayer();
}

function updateMediaSession(t) {
  if (!("mediaSession" in navigator) || !t) return;
  navigator.mediaSession.metadata = new MediaMetadata({
    title: t.name,
    artist: t.genre,
    album: t.mood,
  });
  navigator.mediaSession.setActionHandler("play", () => togglePlay());
  navigator.mediaSession.setActionHandler("pause", () => togglePlay());
  navigator.mediaSession.setActionHandler("previoustrack", () => stepTrack(-1));
  navigator.mediaSession.setActionHandler("nexttrack", () => stepTrack(1));
}

// ---------- Data ops ----------
async function addFiles(fileList) {
  const incoming = Array.from(fileList).filter(
    (f) => f.type.startsWith("audio/") || /\.(mp3|m4a|wav|ogg|flac|aac)$/i.test(f.name)
  );
  if (incoming.length === 0) return showToast("No audio files found in that selection.");

  const existingKeys = new Set(tracks.map((t) => `${t.name}__${t.size}`));
  let added = 0;
  for (const file of incoming) {
    const key = `${file.name}__${file.size}`;
    if (existingKeys.has(key)) continue;
    const record = {
      name: file.name.replace(/\.[^/.]+$/, ""),
      size: file.size,
      lastModified: file.lastModified,
      genre: guessGenre(file.name),
      mood: "Uplifting",
      blob: file,
    };
    const id = await dbAdd(record);
    record.id = id;
    record.url = URL.createObjectURL(record.blob);
    tracks.push(record);
    added++;
  }
  showToast(added > 0 ? `Added ${added} track${added > 1 ? "s" : ""} to your library.` : "Those tracks are already in your library.");
  renderAll();
}

async function updateTag(id, field, value) {
  const t = tracks.find((x) => x.id === id);
  if (!t) return;
  t[field] = value;
  const { url, ...toSave } = t;
  await dbUpdate(toSave);
  renderAll();
}

async function removeTrack(id) {
  const t = tracks.find((x) => x.id === id);
  if (!t) return;
  await dbDelete(id);
  URL.revokeObjectURL(t.url);
  tracks = tracks.filter((x) => x.id !== id);
  if (currentId === id) {
    currentId = null;
    isPlaying = false;
    audio.pause();
    audio.src = "";
  }
  renderAll();
}

// ---------- Wiring ----------
els.addBtn.addEventListener("click", () => els.fileInput.click());
els.fileInput.addEventListener("change", (e) => {
  addFiles(e.target.files);
  e.target.value = "";
});
els.clearFilter.addEventListener("click", clearFilterFn);
els.shuffleBtn.addEventListener("click", () => {
  shuffle = !shuffle;
  renderPlayer();
});
els.prevBtn.addEventListener("click", () => stepTrack(-1));
els.nextBtn.addEventListener("click", () => stepTrack(1));
els.playBtn.addEventListener("click", togglePlay);
els.volume.addEventListener("input", (e) => (audio.volume = Number(e.target.value)));
els.seek.addEventListener("input", (e) => {
  audio.currentTime = Number(e.target.value);
});

audio.addEventListener("timeupdate", () => {
  els.seek.value = audio.currentTime;
  els.curTime.textContent = formatTime(audio.currentTime);
});
audio.addEventListener("loadedmetadata", () => {
  els.seek.max = audio.duration || 0;
  els.durTime.textContent = formatTime(audio.duration);
});
audio.addEventListener("ended", () => stepTrack(1));

// ---------- Boot ----------
async function boot() {
  audio.volume = Number(els.volume.value);
  db = await openDB();
  const stored = await dbAll();
  tracks = stored.map((t) => ({ ...t, url: URL.createObjectURL(t.blob) }));
  renderAll();

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("service-worker.js").catch(() => {});
  }
}
boot();
